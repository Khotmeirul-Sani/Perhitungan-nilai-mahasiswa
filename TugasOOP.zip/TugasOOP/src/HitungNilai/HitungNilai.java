package HitungNilai;

import java.util.Scanner;

/**
 *
 * @author SanSan
 */
public class HitungNilai {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double nilaiuas, nilaiuts, nilaiquis, nilaitugas;
        double uas,uts,quis,tugas,total;
        int n;
        System.out.println("Selamat Datang");
        System.out.println("Masukkan berapa kali mau mengulang operasi program:");
        Scanner ulang = new Scanner (System.in);
        n= ulang.nextInt();
        
        for(int i=0; i<n;i++){
        Scanner masukan = new Scanner(System.in);
        System.out.println("Masukkan nilai UAS:");
        nilaiuas=masukan.nextDouble();
        System.out.println("Masukkan nilai UTS:");
        nilaiuts=masukan.nextDouble();
        System.out.println("Masukkan nilai Tugas:");
        nilaitugas=masukan.nextDouble();
        System.out.println("Masukkan nilai Quis:");
        nilaiquis=masukan.nextDouble();
        
        uas= 0.40*nilaiuas;
        uts= 0.30*nilaiuts;
        quis= 0.15*nilaiquis;
        tugas = 0.15*nilaitugas;
        
        total = (uas + uts + quis + tugas);
        
        if (total>=85){
            System.out.println("Nilai Angka :"+total);
            System.out.println("Nilai Hurufnya A");
        }
        else if(total<=85 && total >=70){
            System.out.println("Nilai Angka:"+total);
            System.out.println("Nilai Hurufnya B");
        }
        else if (total<70 && total>=60){
            System.out.println("Nilai angka:"+total);
            System.out.println("Nilai Hurufnya C");
        }
        else if (total<60 && total>50){
            System.out.println("Nilai angka : "+total);
            System.out.println("Nilai Hurufnya D");
        }
        else System.out.println("Nilai angka: "+total);
        	 System.out.println("Nilai Hurufnya E");
        }   
}
}